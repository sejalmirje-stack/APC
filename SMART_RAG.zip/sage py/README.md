# 🧠 SmartRAG – 100% Offline Multimodal Document Question Answering System

SmartRAG is an intelligent Retrieval-Augmented Generation (RAG) system built in Python that runs **100% locally and offline without requiring any external API keys or cloud services**.

It understands **both text documents and visual diagrams/charts** in your documents.

---

## 🔒 100% Offline & Private (Option A: Built-in)

- **Zero API Keys Required**: No Google Gemini, no OpenAI, no internet connection needed.
- **Local Diagram & Chart Reader**: Uses **RapidOCR (ONNX)** to parse labels, arrows, flows, and data from diagrams directly on your CPU.
- **Local Hybrid Search**: Combines **ChromaDB (all-MiniLM-L6-v2)** dense embeddings with **BM25Okapi** sparse keyword matching.
- **Local Grounded Answer Synthesizer**: Formats grounded answers with exact source page numbers and renders referenced diagrams inline.
- **Optional Cloud & Ollama LLM Connectors**: You can optionally enable Gemini, OpenAI, or Ollama from the sidebar anytime.

---

## ✨ Key Features

- **🖼️ Multimodal Diagram & Chart Aware**:
  - Automatically extracts embedded diagrams, flowcharts, architectures, and plots from PDFs and Word documents.
  - Analyzes figures using **Multimodal Vision AI** (Gemini Vision / GPT-4o) and indexes rich visual semantics.
  - Renders the **actual referenced diagram/chart inline** in the chat response.
- **⚡ Hybrid Search Engine**:
  - **Dense Semantic Embeddings** (ChromaDB) + **Sparse Keyword Matching** (BM25Okapi).
  - Merged using **Reciprocal Rank Fusion (RRF)** for high-precision retrieval of acronyms, exact IDs, and semantic concepts.
- **📚 Multi-Format Document Ingestion**:
  - Supports **PDF** (`.pdf`), **Word** (`.docx`), **Text/Markdown** (`.txt`, `.md`), **Data Tables** (`.csv`, `.xlsx`), and **Standalone Images** (`.png`, `.jpg`).
- **📑 Traceable Citations**:
  - Every answer cites exact document names, page numbers, match scores, and excerpt previews.
- **💬 Conversational Memory**:
  - Multi-turn conversational memory with query contextualization for smooth follow-up questions.
- **🎨 Interactive Streamlit Dashboard**:
  - Drag-and-drop file uploader with indexing progress bar.
  - Dedicated **Extracted Visuals Gallery** to inspect all figures found in your documents.
  - **Chunk Inspector** to examine raw indexed tokens and metadata.

---

## 🏗️ Architecture

```
[Documents (PDF, DOCX, CSV, TXT)]
       │
       ├──► 1. Text Parsing & Recursive Chunking ──► [ChromaDB Vector Store]
       │                                                      │
       └──► 2. PyMuPDF Diagram Extraction                    ▼
               + Multimodal Vision Captioning  ──► [BM25 Keyword Index]
                                                              │
                                                              ▼
                                                 [Hybrid Search Fusion (RRF)]
                                                              │
                                                              ▼
                                                 [Context & Memory Assembler]
                                                              │
                                                              ▼
                                                 [LLM (Gemini / OpenAI / Ollama)]
                                                              │
                                                              ▼
                                            [Answer + Inline Diagram + Citations]
```

---

## 🚀 Quickstart

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up API Keys (Optional)
Copy `.env.example` to `.env` or set your API key in the sidebar of the Streamlit application:
```bash
GEMINI_API_KEY=your_gemini_api_key_here
```
> *Tip: You can get a free Gemini API key from [Google AI Studio](https://aistudio.google.com).*

### 3. Launch the Application
```bash
streamlit run app.py
```
The app will open automatically in your browser at `http://localhost:8501`.

---

## 📁 Project Structure

```
SmartRAG/
├── app.py                     # Streamlit frontend & interactive UI
├── config.py                  # App configuration & default parameters
├── requirements.txt           # Python dependencies
├── .env.example               # Environment variables template
├── README.md                  # System documentation
├── test_smartrag.py           # Verification script
│
├── core/
│   ├── document_loader.py     # Multi-format document parser
│   ├── visual_extractor.py    # Diagram & chart extractor + Vision AI
│   ├── chunker.py             # Recursive text splitter with overlap
│   ├── vector_store.py        # ChromaDB persistent vector storage
│   ├── hybrid_retriever.py    # BM25 + Vector Search + RRF Re-ranking
│   ├── generator.py           # Multi-provider LLM answer synthesizer
│   └── rag_engine.py          # Unified coordinator pipeline
│
└── data/                      # Local vector database & extracted diagrams
```

---

## 🛠️ Supported LLM Backends

- **Google Gemini** (Default: `gemini-2.5-flash`, `gemini-1.5-flash`, `gemini-2.0-flash`) - *Recommended for fast multimodal vision.*
- **OpenAI** (`gpt-4o-mini`, `gpt-4o`)
- **Ollama** (`llama3.2`, `mistral`) - *For 100% private, local inference.*
- **Offline Preview Mode** - *Runs grounded snippet extraction even without an API key.*

