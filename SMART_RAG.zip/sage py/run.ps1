$env:PYTHONUTF8=1
$env:PYTHONIOENCODING="utf-8"
Write-Host "Starting SmartRAG Web Dashboard..." -ForegroundColor Cyan
python -m streamlit run app.py

