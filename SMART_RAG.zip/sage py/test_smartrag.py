import sys
from pathlib import Path
from PIL import Image, ImageDraw

# Ensure utf-8 stdout on Windows terminal
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.rag_engine import SmartRAGEngine
from config import DATA_DIR

def run_test():
    print("=== Testing SmartRAG Pipeline ===")
    
    # 1. Create a dummy test diagram image
    test_img_path = DATA_DIR / "sample_architecture_diagram.png"
    img = Image.new("RGB", (400, 250), color=(240, 244, 248))
    draw = ImageDraw.Draw(img)
    # Draw simple boxes representing system architecture
    draw.rectangle([30, 80, 150, 160], outline=(40, 80, 180), width=3, fill=(210, 230, 255))
    draw.text((45, 110), "Frontend UI\n(Streamlit)", fill=(10, 30, 80))
    
    draw.rectangle([250, 80, 370, 160], outline=(30, 160, 60), width=3, fill=(220, 250, 220))
    draw.text((265, 110), "Vector Store\n(ChromaDB)", fill=(10, 60, 20))
    
    draw.line([(150, 120), (250, 120)], fill=(0, 0, 0), width=3)
    img.save(test_img_path)
    print(f"Created sample diagram at: {test_img_path}")

    # 2. Create a dummy test text document
    test_txt_path = DATA_DIR / "system_spec.txt"
    sample_text = """
    SmartRAG System Specification:
    Project Name: SmartRAG Multimodal Intelligence
    Version: 2.0.0
    Authors: DeepMind & Antigravity Engineering
    
    Key Components:
    1. Document Loader: Parses PDF, DOCX, TXT, CSV, and images.
    2. Hybrid Search Engine: Combines dense vector similarity with sparse BM25 keyword search.
    3. Multimodal Diagram Extractor: Extracts charts and flowcharts using PyMuPDF and analyzes them via Vision AI.
    4. Conversational Generator: Connects to Gemini 2.5 Flash, OpenAI, or local Ollama.
    
    Performance Metrics:
    - Average retrieval latency is under 45ms.
    - Hallucination reduction score improved by 78% using Reciprocal Rank Fusion.
    """
    with open(test_txt_path, "w", encoding="utf-8") as f:
        f.write(sample_text)
    print(f"Created sample text spec at: {test_txt_path}")

    # 3. Initialize Engine
    engine = SmartRAGEngine()
    engine.clear()  # Start fresh
    print("Engine initialized and knowledge base cleared.")

    # 4. Ingest Text Document
    res1 = engine.ingest_file(test_txt_path)
    print(f"Ingested text file: {res1}")

    # 5. Ingest Diagram Image
    res2 = engine.ingest_file(test_img_path)
    print(f"Ingested diagram image: {res2}")

    # 6. Check Stats
    stats = engine.get_stats()
    print(f"Knowledge Base Stats: {stats}")
    assert stats["total_chunks"] >= 2, "Expected at least 2 chunks"
    assert stats["visual_count"] >= 1, "Expected at least 1 visual chunk"

    # 7. Query Test: Keyword + Semantic (Hybrid)
    print("\n--- Testing Query 1: 'What is the hallucination reduction score?' ---")
    ans1 = engine.ask("What is the hallucination reduction score?", use_hybrid=True)
    print(f"Answer:\n{ans1['answer']}\n")
    print(f"Citations count: {len(ans1['citations'])}")

    # 8. Query Test: Visual/Diagram
    print("\n--- Testing Query 2: 'Describe the architecture diagram' ---")
    ans2 = engine.ask("Describe the architecture diagram and what components are connected", use_hybrid=True)
    print(f"Answer:\n{ans2['answer']}\n")
    print(f"Visual citations: {ans2['visual_citations']}")

    print("\n ALL TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    run_test()

