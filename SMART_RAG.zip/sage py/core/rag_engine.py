from pathlib import Path
from typing import List, Dict, Any, Optional
from core.document_loader import DocumentLoader
from core.visual_extractor import VisualExtractor
from core.chunker import RecursiveChunker
from core.vector_store import VectorStore
from core.hybrid_retriever import HybridRetriever
from core.generator import LLMGenerator
from config import CHROMA_DIR, IMAGES_DIR

class SmartRAGEngine:
    """
    Central Coordinator for Document Ingestion, Multimodal Visual Analysis,
    Hybrid Retrieval, and Contextual Answering.
    Runs 100% locally and offline without requiring external API keys.
    """

    def __init__(
        self,
        gemini_api_key: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        ollama_url: Optional[str] = "http://localhost:11434",
        provider: str = "offline",
        model_name: Optional[str] = None
    ):
        self.gemini_api_key = gemini_api_key
        self.openai_api_key = openai_api_key
        self.ollama_url = ollama_url
        self.provider = provider
        self.model_name = model_name

        self.vector_store = VectorStore(persist_dir=CHROMA_DIR)
        self.hybrid_retriever = HybridRetriever(self.vector_store)
        self.visual_extractor = VisualExtractor(gemini_api_key=self.gemini_api_key)
        self.generator = LLMGenerator(
            provider=self.provider,
            gemini_api_key=self.gemini_api_key,
            openai_api_key=self.openai_api_key,
            ollama_url=self.ollama_url,
            model_name=self.model_name
        )

    def update_llm_config(
        self,
        provider: str,
        gemini_api_key: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        model_name: Optional[str] = None
    ):
        """Allows hot-swapping API keys or LLM provider from Streamlit UI."""
        self.provider = provider
        if gemini_api_key is not None:
            self.gemini_api_key = gemini_api_key
            self.visual_extractor = VisualExtractor(gemini_api_key=gemini_api_key)
        if openai_api_key is not None:
            self.openai_api_key = openai_api_key
        self.model_name = model_name

        self.generator = LLMGenerator(
            provider=self.provider,
            gemini_api_key=self.gemini_api_key,
            openai_api_key=self.openai_api_key,
            ollama_url=self.ollama_url,
            model_name=self.model_name
        )

    def ingest_file(
        self,
        file_path: str | Path,
        original_filename: str = None,
        chunk_size: int = 800,
        chunk_overlap: int = 150,
        extract_visuals: bool = True
    ) -> Dict[str, Any]:
        """
        Parses document, extracts diagrams, creates chunks, and indexes into VectorStore & BM25.
        """
        file_path = Path(file_path)
        filename = original_filename or file_path.name
        
        # 1. Extract raw text sections
        raw_pages = DocumentLoader.load_document(file_path, filename)
        
        # 2. Extract diagrams, flowcharts, and figures (if enabled)
        visual_chunks = []
        if extract_visuals:
            try:
                visual_chunks = self.visual_extractor.extract_visuals_from_file(file_path, filename)
            except Exception as e:
                print(f"Visual extraction error on {filename}: {e}")

        # 3. Chunk text sections
        chunker = RecursiveChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        text_chunks = chunker.chunk_documents(raw_pages)

        # 4. Combine text and visual chunks
        all_chunks = text_chunks + visual_chunks

        # 5. Store in Vector Database
        indexed_count = self.vector_store.add_chunks(all_chunks)

        # 6. Refresh Hybrid Retriever's BM25 index
        self.hybrid_retriever.refresh_index()

        return {
            "filename": filename,
            "text_chunks": len(text_chunks),
            "visual_chunks": len(visual_chunks),
            "total_indexed": indexed_count
        }

    def ask(
        self,
        query: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        top_k: int = 4,
        use_hybrid: bool = True
    ) -> Dict[str, Any]:
        """
        Executes query retrieval, fusion re-ranking, and response synthesis.
        """
        # 1. Retrieve most relevant context chunks
        matched_chunks = self.hybrid_retriever.retrieve(
            query=query,
            top_k=top_k,
            use_hybrid=use_hybrid
        )

        # 2. Synthesize answer with citations
        result = self.generator.generate_answer(
            query=query,
            context_chunks=matched_chunks,
            conversation_history=conversation_history
        )

        result["retrieved_chunks"] = matched_chunks
        return result

    def get_stats(self) -> Dict[str, Any]:
        return self.vector_store.get_stats()

    def get_all_visuals(self) -> List[Dict[str, Any]]:
        """Returns all indexed visual chunks for document gallery exploration."""
        all_chunks = self.vector_store.get_all_chunks()
        visuals = []
        for c in all_chunks:
            meta = c.get("metadata", {})
            if meta.get("type") == "visual" and meta.get("image_path"):
                visuals.append({
                    "source": meta.get("source"),
                    "page": meta.get("page"),
                    "caption": meta.get("caption") or c["content"],
                    "image_path": meta.get("image_path")
                })
        return visuals

    def clear(self):
        """Clears vector store and hybrid index."""
        self.vector_store.clear()
        self.hybrid_retriever.refresh_index()

