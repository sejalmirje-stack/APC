import os
import uuid
import io
from pathlib import Path
from typing import List, Dict, Any, Optional
from PIL import Image
import fitz  # PyMuPDF
from config import IMAGES_DIR

class VisualExtractor:
    """
    Extracts embedded diagrams, flowcharts, charts, and figures from documents,
    extracts diagram text & labels using 100% offline local RapidOCR, and packages
    them as searchable visual chunks with image references.
    """

    def __init__(self, gemini_api_key: Optional[str] = None):
        self.gemini_api_key = gemini_api_key
        self._gemini_client = None
        self._ocr = None

        # Initialize local offline RapidOCR
        try:
            from rapidocr_onnxruntime import RapidOCR
            self._ocr = RapidOCR()
        except Exception as e:
            print(f"Warning: Local RapidOCR not available: {e}")

        # Optional Gemini Vision client if API key is provided
        if self.gemini_api_key:
            try:
                from google import genai
                self._gemini_client = genai.Client(api_key=self.gemini_api_key)
            except Exception as e:
                print(f"Notice: Gemini Vision client not enabled: {e}")

    def extract_visuals_from_file(self, file_path: str | Path, original_filename: str = None) -> List[Dict[str, Any]]:
        """
        Extracts diagrams/images and returns a list of visual chunk dictionaries.
        """
        file_path = Path(file_path)
        filename = original_filename or file_path.name
        ext = file_path.suffix.lower()

        visual_items = []
        if ext == ".pdf":
            visual_items = self._extract_from_pdf(file_path, filename)
        elif ext == ".docx":
            visual_items = self._extract_from_docx(file_path, filename)
        elif ext in [".png", ".jpg", ".jpeg", ".webp", ".bmp"]:
            visual_items = self._extract_from_image(file_path, filename)

        # Generate descriptive captions for the extracted visuals using offline OCR / Vision
        visual_chunks = []
        for item in visual_items:
            caption, detected_text = self._generate_visual_caption(item["image_path"], item["page"], filename)
            chunk_text = (
                f"[Visual Diagram/Figure from {filename}, Page {item['page']}]\n"
                f"Description: {caption}\n"
                f"Labels & Text in Diagram: {detected_text}"
            )
            chunk_id = str(uuid.uuid4())
            visual_chunks.append({
                "id": chunk_id,
                "content": chunk_text,
                "metadata": {
                    "source": filename,
                    "page": item["page"],
                    "type": "visual",
                    "image_path": str(item["image_path"]),
                    "caption": caption,
                    "diagram_text": detected_text,
                    "chunk_id": chunk_id
                }
            })

        return visual_chunks

    def _extract_from_pdf(self, file_path: Path, filename: str) -> List[Dict[str, Any]]:
        extracted = []
        try:
            doc = fitz.open(file_path)
            for page_idx, page in enumerate(doc):
                image_list = page.get_images(full=True)
                for img_idx, img_info in enumerate(image_list):
                    xref = img_info[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    image_ext = base_image["ext"]

                    # Filter out tiny icon decorations (< 100x100)
                    try:
                        pil_img = Image.open(io.BytesIO(image_bytes))
                        width, height = pil_img.size
                        if width < 120 or height < 120:
                            continue  # Skip tiny icons or bullet points
                        
                        unique_id = uuid.uuid4().hex[:8]
                        save_name = f"{Path(filename).stem}_p{page_idx + 1}_img{img_idx + 1}_{unique_id}.{image_ext}"
                        save_path = IMAGES_DIR / save_name
                        with open(save_path, "wb") as f:
                            f.write(image_bytes)

                        extracted.append({
                            "page": page_idx + 1,
                            "image_path": save_path
                        })
                    except Exception:
                        continue
            doc.close()
        except Exception as e:
            print(f"Error extracting images from PDF {filename}: {e}")
        return extracted

    def _extract_from_docx(self, file_path: Path, filename: str) -> List[Dict[str, Any]]:
        extracted = []
        try:
            import zipfile
            with zipfile.ZipFile(file_path) as z:
                media_files = [f for f in z.namelist() if f.startswith("word/media/")]
                for idx, media_path in enumerate(media_files):
                    img_data = z.read(media_path)
                    try:
                        pil_img = Image.open(io.BytesIO(img_data))
                        width, height = pil_img.size
                        if width < 120 or height < 120:
                            continue

                        ext = Path(media_path).suffix or ".png"
                        unique_id = uuid.uuid4().hex[:8]
                        save_name = f"{Path(filename).stem}_media{idx + 1}_{unique_id}{ext}"
                        save_path = IMAGES_DIR / save_name
                        with open(save_path, "wb") as f:
                            f.write(img_data)

                        extracted.append({
                            "page": 1,
                            "image_path": save_path
                        })
                    except Exception:
                        continue
        except Exception as e:
            print(f"Error extracting images from DOCX {filename}: {e}")
        return extracted

    def _extract_from_image(self, file_path: Path, filename: str) -> List[Dict[str, Any]]:
        unique_id = uuid.uuid4().hex[:8]
        save_name = f"{Path(filename).stem}_{unique_id}{file_path.suffix}"
        save_path = IMAGES_DIR / save_name
        try:
            img = Image.open(file_path)
            img.save(save_path)
            return [{
                "page": 1,
                "image_path": save_path
            }]
        except Exception as e:
            print(f"Error copying standalone image: {e}")
            return []

    def _generate_visual_caption(self, image_path: Path, page_num: int, filename: str) -> tuple[str, str]:
        """
        Uses 100% Local RapidOCR to read diagram labels, flow text, and structure.
        Optionally uses Gemini Vision if an API key is explicitly configured.
        Returns (caption, detected_text).
        """
        detected_labels = []

        # 1. 100% Offline Local OCR extraction
        if self._ocr:
            try:
                ocr_results, _ = self._ocr(str(image_path))
                if ocr_results:
                    for item in ocr_results:
                        if len(item) >= 2 and item[1]:
                            text = item[1].strip()
                            if text and text not in detected_labels:
                                detected_labels.append(text)
            except Exception as e:
                print(f"Local OCR error for {image_path.name}: {e}")

        detected_text_str = ", ".join(detected_labels) if detected_labels else "No textual labels detected."

        # 2. Cloud Vision (Optional fallback if user configured API key)
        if self._gemini_client:
            try:
                pil_img = Image.open(image_path)
                prompt = (
                    "Analyze this diagram, chart, or architecture image.\n"
                    "Provide a brief summary of what it shows, key components, and data points."
                )
                response = self._gemini_client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=[pil_img, prompt]
                )
                if response and response.text:
                    return response.text.strip(), detected_text_str
            except Exception:
                pass

        # 3. Offline Heuristic Structured Caption
        try:
            pil_img = Image.open(image_path)
            w, h = pil_img.size
            if detected_labels:
                caption = (
                    f"Visual Diagram/Chart from '{filename}' (Page {page_num}, {w}x{h} px). "
                    f"Contains {len(detected_labels)} identified visual components/labels: {detected_text_str}."
                )
            else:
                caption = f"Visual Figure/Image from '{filename}' (Page {page_num}, {w}x{h} px)."
        except Exception:
            caption = f"Diagram/Figure from '{filename}', Page {page_num}."

        return caption, detected_text_str

