import os
import re
from pathlib import Path
from typing import List, Dict, Any
import pypdf
import fitz  # PyMuPDF
from docx import Document
import pandas as pd

class DocumentLoader:
    """
    Multi-format document loader extracting structured text with page and location metadata.
    Supported formats: .pdf, .docx, .txt, .md, .csv, .xlsx
    """

    @staticmethod
    def load_document(file_path: str | Path, original_filename: str = None) -> List[Dict[str, Any]]:
        """
        Loads document content and returns a list of page/section dictionaries:
        [
            {
                "content": str,
                "metadata": {
                    "source": filename,
                    "page": int,
                    "type": "text"
                }
            },
            ...
        ]
        """
        file_path = Path(file_path)
        filename = original_filename or file_path.name
        ext = file_path.suffix.lower()

        if ext == ".pdf":
            return DocumentLoader._load_pdf(file_path, filename)
        elif ext == ".docx":
            return DocumentLoader._load_docx(file_path, filename)
        elif ext in [".txt", ".md", ".log"]:
            return DocumentLoader._load_text(file_path, filename)
        elif ext in [".csv", ".tsv"]:
            return DocumentLoader._load_csv(file_path, filename)
        elif ext in [".xlsx", ".xls"]:
            return DocumentLoader._load_excel(file_path, filename)
        elif ext in [".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tiff"]:
            return [{
                "content": f"[Standalone Diagram/Image: {filename}]",
                "metadata": {
                    "source": filename,
                    "page": 1,
                    "type": "image"
                }
            }]
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    @staticmethod
    def _clean_text(text: str) -> str:
        """Fixes hyphenations across linebreaks and merges wrapped lines in academic/two-column papers."""
        if not text:
            return ""
        # Fix hyphenated words broken across lines: e.g. "demon-\nstration" -> "demonstration"
        text = re.sub(r"(\w+)-\s*\n\s*(\w+)", r"\1\2", text)
        # Merge soft line breaks inside paragraphs while preserving actual paragraph breaks (\n\n)
        paragraphs = text.split("\n\n")
        cleaned_paras = []
        for p in paragraphs:
            # Replace single newlines within paragraph with space
            cleaned_p = re.sub(r"(?<!\n)\n(?!\n)", " ", p.strip())
            # Clean excessive multiple spaces
            cleaned_p = re.sub(r"[ \t]+", " ", cleaned_p)
            if cleaned_p:
                cleaned_paras.append(cleaned_p)
        return "\n\n".join(cleaned_paras)

    @staticmethod
    def _load_pdf(file_path: Path, filename: str) -> List[Dict[str, Any]]:
        pages = []
        try:
            # PyMuPDF block-level extraction for proper multi-column reading order
            doc = fitz.open(file_path)
            for page_idx, page in enumerate(doc):
                blocks = page.get_text("blocks")
                # Sort blocks by horizontal column (x0) and vertical (y0) to correctly read two-column papers
                # Most two-column papers split around middle (x0 < 300 for left column, x0 >= 300 for right)
                def sort_key(b):
                    x0, y0, x1, y1, text, b_no, b_type = b[:7]
                    col = 0 if x0 < 300 else 1
                    return (col, y0)

                sorted_blocks = sorted(blocks, key=sort_key)
                block_texts = [b[4] for b in sorted_blocks if b[6] == 0 and b[4].strip()]
                raw_text = "\n\n".join(block_texts)
                cleaned = DocumentLoader._clean_text(raw_text)

                if cleaned:
                    pages.append({
                        "content": cleaned,
                        "metadata": {
                            "source": filename,
                            "page": page_idx + 1,
                            "type": "text"
                        }
                    })
            doc.close()
        except Exception:
            # Fallback to pypdf
            reader = pypdf.PdfReader(str(file_path))
            for page_idx, page in enumerate(reader.pages):
                text = page.extract_text() or ""
                cleaned = DocumentLoader._clean_text(text)
                if cleaned:
                    pages.append({
                        "content": cleaned,
                        "metadata": {
                            "source": filename,
                            "page": page_idx + 1,
                            "type": "text"
                        }
                    })
        return pages

    @staticmethod
    def _load_docx(file_path: Path, filename: str) -> List[Dict[str, Any]]:
        doc = Document(file_path)
        paragraphs = []
        
        # Extract normal text
        for p in doc.paragraphs:
            text = p.text.strip()
            if text:
                paragraphs.append(text)
        
        # Extract tables as structured markdown
        for table in doc.tables:
            table_rows = []
            for row in table.rows:
                row_cells = [cell.text.strip() for cell in row.cells]
                if any(row_cells):
                    table_rows.append(" | ".join(row_cells))
            if table_rows:
                paragraphs.append("\n[Structured Table]:\n" + "\n".join(table_rows))

        combined_text = "\n\n".join(paragraphs)
        return [{
            "content": combined_text,
            "metadata": {
                "source": filename,
                "page": 1,
                "type": "text"
            }
        }]

    @staticmethod
    def _load_text(file_path: Path, filename: str) -> List[Dict[str, Any]]:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
        except UnicodeDecodeError:
            with open(file_path, "r", encoding="latin-1") as f:
                content = f.read().strip()

        return [{
            "content": content,
            "metadata": {
                "source": filename,
                "page": 1,
                "type": "text"
            }
        }]

    @staticmethod
    def _load_csv(file_path: Path, filename: str) -> List[Dict[str, Any]]:
        df = pd.read_csv(file_path)
        # Summarize columns and data preview
        rows_text = []
        rows_text.append(f"Table columns: {', '.join(df.columns)}")
        rows_text.append(f"Total rows: {len(df)}")
        
        # Format rows into readable sentences/JSON-like chunks
        for idx, row in df.iterrows():
            row_str = ", ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
            rows_text.append(f"Row {idx + 1}: {row_str}")

        return [{
            "content": "\n".join(rows_text),
            "metadata": {
                "source": filename,
                "page": 1,
                "type": "text"
            }
        }]

    @staticmethod
    def _load_excel(file_path: Path, filename: str) -> List[Dict[str, Any]]:
        xls = pd.ExcelFile(file_path)
        all_sheets = []
        for sheet_idx, sheet_name in enumerate(xls.sheet_names):
            df = pd.read_excel(xls, sheet_name=sheet_name)
            sheet_text = [f"Sheet: {sheet_name}", f"Columns: {', '.join(map(str, df.columns))}"]
            for idx, row in df.iterrows():
                row_str = ", ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
                sheet_text.append(f"Row {idx + 1}: {row_str}")
            all_sheets.append({
                "content": "\n".join(sheet_text),
                "metadata": {
                    "source": filename,
                    "page": sheet_idx + 1,
                    "sheet": sheet_name,
                    "type": "text"
                }
            })
        return all_sheets