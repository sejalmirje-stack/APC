import os
import re
from typing import List, Dict, Any, Optional
from PIL import Image

class LLMGenerator:
    """
    Unified answer generator supporting:
    1. 100% Offline Local Grounded Synthesizer (Default - No API key needed)
    2. Optional Google Gemini API
    3. Optional OpenAI API
    4. Optional Local Ollama
    """

    def __init__(
        self,
        provider: str = "offline",
        gemini_api_key: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        ollama_url: Optional[str] = "http://localhost:11434",
        model_name: Optional[str] = None
    ):
        self.provider = provider.lower()
        self.gemini_api_key = gemini_api_key or os.getenv("GEMINI_API_KEY", "")
        self.openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY", "")
        self.ollama_url = ollama_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.model_name = model_name

        self._gemini_client = None
        if self.gemini_api_key and self.provider == "gemini":
            try:
                from google import genai
                self._gemini_client = genai.Client(api_key=self.gemini_api_key)
            except Exception as e:
                print(f"Error initializing Gemini client: {e}")

    def generate_answer(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Synthesizes a grounded answer from retrieved context chunks and conversation history.
        Returns:
        {
            "answer": str,
            "citations": List[Dict],
            "visual_citations": List[str]  # Paths to diagrams/figures cited
        }
        """
        if not context_chunks:
            return {
                "answer": (
                    "**No matching information found.**\n\n"
                    "The uploaded documents do not appear to contain relevant information for your query. "
                    "Try uploading additional documents or rephrasing your search terms."
                ),
                "citations": [],
                "visual_citations": []
            }

        # Collect citations and visual images
        citations = []
        visual_images = []

        for idx, chunk in enumerate(context_chunks):
            meta = chunk.get("metadata", {})
            source = meta.get("source", "Document")
            page = meta.get("page", 1)
            chunk_type = meta.get("type", "text")
            image_path = meta.get("image_path")

            citations.append({
                "index": idx + 1,
                "source": source,
                "page": page,
                "type": chunk_type,
                "score": chunk.get("rrf_score") or chunk.get("score", 0),
                "preview": chunk["content"][:220] + ("..." if len(chunk["content"]) > 220 else ""),
                "image_path": image_path,
                "content": chunk["content"]
            })

            if image_path and os.path.exists(image_path) and image_path not in visual_images:
                visual_images.append(image_path)

        # 1. Cloud API option: Gemini
        if self.provider == "gemini" and self._gemini_client:
            full_prompt, sys_inst = self._build_prompt(query, context_chunks, conversation_history)
            answer_text = self._call_gemini(full_prompt, visual_images)
            if answer_text:
                return {
                    "answer": answer_text,
                    "citations": citations,
                    "visual_citations": visual_images
                }

        # 2. Cloud API option: OpenAI
        elif self.provider == "openai" and self.openai_api_key:
            full_prompt, sys_inst = self._build_prompt(query, context_chunks, conversation_history)
            answer_text = self._call_openai(sys_inst, full_prompt)
            if answer_text:
                return {
                    "answer": answer_text,
                    "citations": citations,
                    "visual_citations": visual_images
                }

        # 3. Local Ollama option
        elif self.provider == "ollama":
            full_prompt, sys_inst = self._build_prompt(query, context_chunks, conversation_history)
            answer_text = self._call_ollama(sys_inst, full_prompt)
            if answer_text:
                return {
                    "answer": answer_text,
                    "citations": citations,
                    "visual_citations": visual_images
                }

        # 4. 100% Offline Local Grounded Synthesizer (Default, No API Required)
        answer_text = self._offline_grounded_synthesizer(query, citations)
        return {
            "answer": answer_text,
            "citations": citations,
            "visual_citations": visual_images
        }

    def _build_prompt(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> tuple[str, str]:
        context_blocks = []
        for idx, chunk in enumerate(context_chunks):
            meta = chunk.get("metadata", {})
            header = f"[Source {idx+1}: {meta.get('source', 'Doc')} (Page {meta.get('page', 1)})]"
            context_blocks.append(f"{header}\n{chunk['content']}")

        system_instruction = (
            "You are SmartRAG, an intelligent multimodal document question answering system.\n"
            "Answer strictly based on the provided document excerpts and diagram descriptions.\n"
            "Cite the source and page number for facts."
        )

        history_lines = []
        if conversation_history:
            for msg in conversation_history[-4:]:
                r = "User" if msg["role"] == "user" else "Assistant"
                history_lines.append(f"{r}: {msg['content']}")

        history_str = ("Conversation History:\n" + "\n".join(history_lines) + "\n\n") if history_lines else ""
        full_prompt = (
            f"{history_str}Provided Excerpts:\n" + "\n\n---\n\n".join(context_blocks) +
            f"\n\nUser Question: {query}\n\nAnswer:"
        )
        return full_prompt, system_instruction

    def _offline_grounded_synthesizer(self, query: str, citations: List[Dict[str, Any]]) -> str:
        """
        Comprehensive grounded synthesizer that provides in-depth, complete answers
        faithful to the original document, preserving definitions, components, tables,
        uses, and advantages without premature truncation.
        """
        query_words = set(re.findall(r"\w+", query.lower()))
        stop_words = {
            "what", "is", "the", "are", "and", "in", "to", "of", "how", "a", "an",
            "for", "on", "with", "can", "you", "tell", "me", "about", "give", "show",
            "explain", "list", "do", "does", "did", "please", "describe"
        }
        keywords = query_words - stop_words or query_words

        # Separate text chunks and visual chunks
        text_chunks = [c for c in citations if c.get("type") != "visual"]
        visual_chunks = [c for c in citations if c.get("type") == "visual"]

        if not text_chunks and not visual_chunks:
            return "I couldn't find relevant information in the uploaded documents to answer that. Could you try asking about a different topic or rephrasing?"

        # Identify primary source and page
        primary_chunk = text_chunks[0] if text_chunks else visual_chunks[0]
        primary_source = primary_chunk.get("source", "your document")
        primary_page = primary_chunk.get("page", 1)
        topic_title = " ".join([w.capitalize() for w in query.split() if w.lower() not in stop_words]) or query

        response_parts = []
        response_parts.append(f"Based on **{primary_source}** (Page {primary_page}), here is the complete information regarding **{topic_title}**:\n")

        # Collect and merge relevant content from the top matching chunks
        # If multiple chunks come from the same or sequential pages, keep their full content
        merged_sections = []
        seen_texts = set()

        for c in text_chunks[:4]:
            content = c["content"].strip()
            # De-duplicate identical chunks
            fingerprint = content[:80]
            if fingerprint in seen_texts:
                continue
            seen_texts.add(fingerprint)

            # Check if this chunk has strong relevance to the user's keywords
            c_words = set(re.findall(r"\w+", content.lower()))
            if len(keywords & c_words) > 0 or len(merged_sections) == 0:
                merged_sections.append({
                    "page": c["page"],
                    "content": content
                })

        # Process each relevant section into clean, readable, well-formatted markdown
        for sec in merged_sections:
            sec_text = sec["content"]

            # Format headings (e.g. "COMPONENTS OF A LINE PLOT", "USES AND SIGNIFICANCE", "ADVANTAGES")
            # Replace lines that look like all-caps or numbered headings with clean markdown headers
            formatted_lines = []
            for line in sec_text.split("\n"):
                stripped = line.strip()
                if not stripped:
                    formatted_lines.append("")
                    continue

                # Clean bullet characters like  or special symbols
                stripped = re.sub(r"^[•\-\*]\s*", "", stripped)

                # Heading detection (ALL CAPS or numbered title)
                if (stripped.isupper() and len(stripped) > 4 and len(stripped) < 60) or re.match(r"^[0-9]+\.\s+[A-Z\s]{4,}$", stripped):
                    formatted_lines.append(f"\n### 📌 {stripped.title()}\n")
                # Numbered sub-items like "1. Trend Analysis"
                elif re.match(r"^[0-9]+\.\s+[A-Za-z\s]+", stripped) and len(stripped) < 50:
                    formatted_lines.append(f"\n**{stripped}**")
                # Definition or key label with colon
                elif re.match(r"^[A-Za-z\s]{3,25}:", stripped):
                    parts = stripped.split(":", 1)
                    formatted_lines.append(f"**{parts[0].strip()}:** {parts[1].strip()}")
                else:
                    formatted_lines.append(stripped)

            cleaned_body = "\n".join(formatted_lines)
            # Remove excessive newlines
            cleaned_body = re.sub(r"\n{3,}", "\n\n", cleaned_body)
            response_parts.append(cleaned_body)
            response_parts.append("")

        # Incorporate Visual Diagram Information conversationally
        if visual_chunks:
            response_parts.append("### 🖼️ Extracted Diagrams & Figures:")
            for v in visual_chunks[:2]:
                meta_content = v["content"]
                desc_lines = [l.strip() for l in meta_content.split("\n") if l.strip() and not l.startswith("[Visual")]
                desc_clean = " ".join(desc_lines)
                response_parts.append(
                    f"- **Figure from `{v.get('source')}` (Page {v.get('page')}):** {desc_clean}\n"
                )

        # Conversational closing
        response_parts.append(
            "\n💡 *You can ask follow-up questions about any specific component, formula, use-case, or diagram shown above!*"
        )

        return "\n".join(response_parts)

    def _call_gemini(self, prompt: str, visual_images: List[str]) -> str:
        try:
            model = self.model_name or "gemini-2.5-flash"
            contents: List[Any] = []
            
            # If visual chunks were retrieved, include up to 2 referenced images directly in multimodal prompt
            for img_p in visual_images[:2]:
                try:
                    pil_img = Image.open(img_p)
                    contents.append(pil_img)
                except Exception:
                    pass

            contents.append(prompt)
            response = self._gemini_client.models.generate_content(
                model=model,
                contents=contents
            )
            if response and response.text:
                return response.text.strip()
        except Exception as e:
            return f"*(Gemini API Warning: {e})*\n\n" + self._offline_grounded_synthesizer(prompt, [])
        return ""

    def _call_openai(self, system_instruction: str, prompt: str) -> str:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=self.openai_api_key)
            model = self.model_name or "gpt-4o-mini"
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_instruction},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"*(OpenAI API Warning: {e})*\n\n"
        return ""

    def _call_ollama(self, system_instruction: str, prompt: str) -> str:
        try:
            import requests
            model = self.model_name or "llama3.2"
            res = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": model,
                    "prompt": f"{system_instruction}\n\n{prompt}",
                    "stream": False
                },
                timeout=60
            )
            if res.status_code == 200:
                return res.json().get("response", "").strip()
        except Exception as e:
            return f"*(Ollama Warning: {e})*\n\n"
        return ""

    def _fallback_synthesizer(self, query: str, context_chunks: List[Dict[str, Any]]) -> str:
        """
        Graceful fallback answer if no LLM API key has been added yet.
        Summarizes the top matching excerpts cleanly.
        """
        if not context_chunks:
            return "No matching document excerpts were found."

        top_chunk = context_chunks[0]
        meta = top_chunk.get("metadata", {})
        source = meta.get("source", "Document")
        page = meta.get("page", 1)

        summary_lines = [
            f"### SmartRAG Grounded Retrieval Summary",
            f"*Note: To generate fully synthesized conversational prose, enter your Gemini API Key in the left sidebar.*",
            "",
            f"**Most Relevant Match ({source}, Page {page}):**",
            f"> {top_chunk['content']}",
            ""
        ]

        if len(context_chunks) > 1:
            summary_lines.append("**Additional Supporting Excerpts:**")
            for c in context_chunks[1:]:
                m = c.get("metadata", {})
                summary_lines.append(f"- **{m.get('source')} (Page {m.get('page')})**: {c['content'][:180]}...")

        return "\n".join(summary_lines)

