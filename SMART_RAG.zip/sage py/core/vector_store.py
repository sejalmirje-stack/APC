import uuid
import shutil
from pathlib import Path
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.utils import embedding_functions
from config import CHROMA_DIR

class VectorStore:
    """
    Manages persistent vector embeddings and similarity queries using ChromaDB.
    """

    def __init__(self, persist_dir: Path = CHROMA_DIR, collection_name: str = "smart_rag_collection"):
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self.collection_name = collection_name
        self.embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        
        self.client = chromadb.PersistentClient(path=str(self.persist_dir))
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"}
        )

    def add_chunks(self, chunks: List[Dict[str, Any]]) -> int:
        """
        Adds or updates chunks in the Chroma vector collection.
        """
        if not chunks:
            return 0

        ids = []
        documents = []
        metadatas = []
        seen_ids = set()

        for chunk in chunks:
            raw_id = chunk.get("id")
            if not raw_id or str(raw_id).strip() in ("", "None"):
                chunk_id = str(uuid.uuid4())
            else:
                chunk_id = str(raw_id).strip()

            # Ensure uniqueness across the batch
            while chunk_id in seen_ids:
                chunk_id = f"{chunk_id}_{uuid.uuid4().hex[:6]}"
            seen_ids.add(chunk_id)

            content = chunk.get("content", "").strip()
            raw_meta = chunk.get("metadata", {})

            # Chroma metadata values must be string, int, float, or bool
            clean_meta = {}
            for k, v in raw_meta.items():
                if isinstance(v, (str, int, float, bool)):
                    clean_meta[k] = v
                else:
                    clean_meta[k] = str(v)

            if content:
                ids.append(chunk_id)
                documents.append(content)
                metadatas.append(clean_meta)

        if ids:
            self.collection.upsert(
                ids=ids,
                documents=documents,
                metadatas=metadatas
            )

        return len(ids)

    def search(self, query: str, top_k: int = 4) -> List[Dict[str, Any]]:
        """
        Semantic dense search returning top_k chunks with cosine distances.
        """
        if self.collection.count() == 0 or not query.strip():
            return []

        results = self.collection.query(
            query_texts=[query],
            n_results=min(top_k, self.collection.count())
        )

        hits = []
        if results and results["documents"]:
            docs = results["documents"][0]
            metas = results["metadatas"][0] if results.get("metadatas") else [{}] * len(docs)
            distances = results["distances"][0] if results.get("distances") else [0.0] * len(docs)
            ids = results["ids"][0] if results.get("ids") else [""] * len(docs)

            for doc, meta, dist, cid in zip(docs, metas, distances, ids):
                # Cosine distance to similarity: similarity = 1 - distance
                similarity = max(0.0, 1.0 - dist)
                hits.append({
                    "id": cid,
                    "content": doc,
                    "metadata": meta,
                    "score": round(similarity, 4),
                    "search_type": "dense"
                })

        return hits

    def get_all_chunks(self) -> List[Dict[str, Any]]:
        """
        Retrieves all documents and metadata for sparse indexing (BM25).
        """
        if self.collection.count() == 0:
            return []

        data = self.collection.get()
        all_chunks = []
        for cid, doc, meta in zip(data["ids"], data["documents"], data["metadatas"]):
            all_chunks.append({
                "id": cid,
                "content": doc,
                "metadata": meta
            })
        return all_chunks

    def get_stats(self) -> Dict[str, Any]:
        """
        Returns stats about indexed documents, total chunks, and visual figures.
        """
        count = self.collection.count()
        if count == 0:
            return {
                "total_chunks": 0,
                "sources": [],
                "visual_count": 0,
                "text_count": 0
            }

        all_data = self.collection.get()
        sources = set()
        visual_count = 0
        text_count = 0

        for meta in all_data.get("metadatas", []):
            if meta:
                if "source" in meta:
                    sources.add(meta["source"])
                if meta.get("type") == "visual":
                    visual_count += 1
                else:
                    text_count += 1

        return {
            "total_chunks": count,
            "sources": sorted(list(sources)),
            "visual_count": visual_count,
            "text_count": text_count
        }

    def clear(self):
        """
        Resets and clears the collection.
        """
        try:
            self.client.delete_collection(self.collection_name)
        except Exception:
            pass
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"}
        )
