import re
from typing import List, Dict, Any, Optional
from rank_bm25 import BM25Okapi
from core.vector_store import VectorStore

class HybridRetriever:
    """
    Hybrid Retriever combining Dense Vector Search (ChromaDB) and Sparse Keyword Search (BM25)
    with Reciprocal Rank Fusion (RRF) and Re-ranking for maximum retrieval accuracy.
    """

    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.bm25_index: Optional[BM25Okapi] = None
        self.indexed_chunks: List[Dict[str, Any]] = []
        self._build_bm25_index()

    def _tokenize(self, text: str) -> List[str]:
        # Lowercase alphanumeric tokenization
        return re.findall(r"\w+", text.lower())

    def _build_bm25_index(self):
        """Builds or refreshes the in-memory BM25 index from the vector store chunks."""
        self.indexed_chunks = self.vector_store.get_all_chunks()
        if self.indexed_chunks:
            tokenized_corpus = [self._tokenize(c["content"]) for c in self.indexed_chunks]
            self.bm25_index = BM25Okapi(tokenized_corpus)
        else:
            self.bm25_index = None

    def refresh_index(self):
        """Call after new documents or chunks are added."""
        self._build_bm25_index()

    def retrieve(self, query: str, top_k: int = 4, use_hybrid: bool = True) -> List[Dict[str, Any]]:
        """
        Retrieves top_k chunks using either Hybrid Search (Dense + BM25) or pure Dense search.
        """
        if not self.indexed_chunks:
            self._build_bm25_index()

        if not self.indexed_chunks or not query.strip():
            return []

        # If not using hybrid or BM25 index is empty, fallback to pure dense search
        if not use_hybrid or not self.bm25_index:
            return self.vector_store.search(query, top_k=top_k)

        # 1. Dense Semantic Search (retrieve candidates)
        dense_results = self.vector_store.search(query, top_k=min(top_k * 2, len(self.indexed_chunks)))
        
        # 2. Sparse BM25 Search
        tokenized_query = self._tokenize(query)
        bm25_scores = self.bm25_index.get_scores(tokenized_query)
        
        # Sort BM25 results
        bm25_ranked_indices = sorted(range(len(bm25_scores)), key=lambda i: bm25_scores[i], reverse=True)
        top_bm25_indices = bm25_ranked_indices[:min(top_k * 2, len(self.indexed_chunks))]
        
        bm25_results = []
        for idx in top_bm25_indices:
            if bm25_scores[idx] > 0:  # Only if there is at least one keyword match
                chunk = self.indexed_chunks[idx]
                bm25_results.append({
                    "id": chunk["id"],
                    "content": chunk["content"],
                    "metadata": chunk["metadata"],
                    "score": round(float(bm25_scores[idx]), 4),
                    "search_type": "sparse_bm25"
                })

        # 3. Reciprocal Rank Fusion (RRF)
        # RRF formula: score = sum(1 / (60 + rank))
        rrf_constant = 60
        rrf_scores: Dict[str, float] = {}
        chunk_map: Dict[str, Dict[str, Any]] = {}

        for rank, item in enumerate(dense_results):
            cid = item["id"]
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + (1.0 / (rrf_constant + rank + 1))
            chunk_map[cid] = item

        for rank, item in enumerate(bm25_results):
            cid = item["id"]
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + (1.0 / (rrf_constant + rank + 1))
            if cid not in chunk_map:
                chunk_map[cid] = item

        # Sort combined results by RRF score
        sorted_cids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)

        final_chunks = []
        for cid in sorted_cids[:top_k]:
            item = chunk_map[cid]
            # Attach RRF fused score
            item["rrf_score"] = round(rrf_scores[cid], 5)
            final_chunks.append(item)

        return final_chunks

