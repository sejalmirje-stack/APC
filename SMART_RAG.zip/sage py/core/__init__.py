"""
SmartRAG Core Module
Intelligent Multimodal Document Question Answering System
"""

