import re
import uuid
from typing import List, Dict, Any

class RecursiveChunker:
    """
    Splits text recursively by paragraphs, sentences, and punctuation
    while preserving document metadata and context continuity.
    """

    def __init__(self, chunk_size: int = 800, chunk_overlap: int = 150):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def chunk_documents(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Takes raw page objects and outputs discrete chunk dictionaries.
        """
        all_chunks = []

        for doc in documents:
            content = doc.get("content", "").strip()
            meta = doc.get("metadata", {})
            
            # If already a visual chunk or short text, don't oversplit
            if meta.get("type") == "visual" or len(content) <= self.chunk_size:
                chunk_id = str(uuid.uuid4())
                all_chunks.append({
                    "id": chunk_id,
                    "content": content,
                    "metadata": {**meta, "chunk_id": chunk_id}
                })
                continue

            text_splits = self._recursive_split(content, self.chunk_size, self.chunk_overlap)
            for idx, text in enumerate(text_splits):
                chunk_id = str(uuid.uuid4())
                all_chunks.append({
                    "id": chunk_id,
                    "content": text.strip(),
                    "metadata": {
                        **meta,
                        "chunk_id": chunk_id,
                        "chunk_index": idx
                    }
                })

        return all_chunks

    def _recursive_split(self, text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        separators = ["\n\n", "\n", ". ", "; ", ", ", " "]
        
        def _split(txt: str, seps: List[str]) -> List[str]:
            if len(txt) <= chunk_size or not seps:
                return [txt] if txt else []
            
            sep = seps[0]
            parts = txt.split(sep)
            chunks = []
            current = []
            current_len = 0

            for part in parts:
                candidate_len = current_len + len(part) + (len(sep) if current else 0)
                if candidate_len <= chunk_size:
                    current.append(part)
                    current_len = candidate_len
                else:
                    if current:
                        merged = sep.join(current)
                        chunks.append(merged)
                        # Overlap: keep last items that fit into chunk_overlap
                        overlap_items = []
                        overlap_len = 0
                        for item in reversed(current):
                            if overlap_len + len(item) <= chunk_overlap:
                                overlap_items.insert(0, item)
                                overlap_len += len(item) + len(sep)
                            else:
                                break
                        current = overlap_items
                        current_len = sum(len(x) for x in current) + (len(sep) * (len(current) - 1) if current else 0)
                    
                    if len(part) > chunk_size:
                        # Sub-split long item with finer separators
                        sub_chunks = _split(part, seps[1:])
                        chunks.extend(sub_chunks)
                    else:
                        current.append(part)
                        current_len += len(part) + (len(sep) if len(current) > 1 else 0)

            if current:
                chunks.append(sep.join(current))
            return chunks

        return _split(text, separators)

