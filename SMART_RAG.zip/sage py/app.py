import os
import sys
import tempfile
from pathlib import Path
from PIL import Image

# Force UTF-8 encoding on Windows terminal
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

import streamlit as st

from config import (
    DEFAULT_CHUNK_SIZE,
    DEFAULT_CHUNK_OVERLAP,
    DEFAULT_TOP_K,
    GEMINI_API_KEY,
    OPENAI_API_KEY,
    OLLAMA_BASE_URL
)
from core.rag_engine import SmartRAGEngine

# Page Configuration
st.set_page_config(
    page_title="SmartRAG – Multimodal Document Q&A",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for polished interface
st.markdown("""
<style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        color: #6c757d;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }
    .badge {
        display: inline-block;
        padding: 0.25em 0.6em;
        font-size: 78%;
        font-weight: 600;
        border-radius: 0.35rem;
        margin-right: 0.3rem;
        background-color: #2b3035;
        color: #58a6ff;
        border: 1px solid #30363d;
    }
    .citation-card {
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        border: 1px solid #30363d;
        margin-bottom: 0.6rem;
        background-color: rgba(255,255,255,0.03);
    }
    .visual-card {
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #30363d;
        padding: 8px;
        background: rgba(255,255,255,0.02);
        margin-bottom: 12px;
    }
</style>
""", unsafe_allow_html=True)

# Initialize Session State
if "messages" not in st.session_state:
    st.session_state.messages = []

if "gemini_key" not in st.session_state:
    st.session_state.gemini_key = GEMINI_API_KEY

if "openai_key" not in st.session_state:
    st.session_state.openai_key = OPENAI_API_KEY

if "rag_engine" not in st.session_state:
    st.session_state.rag_engine = SmartRAGEngine(
        provider="offline"
    )

# ----------------- SIDEBAR -----------------
with st.sidebar:
    st.title("⚙️ SmartRAG Settings")
    st.markdown("---")

    # Mode Selection (Default: Offline Local Mode)
    mode = st.selectbox(
        "Operating Mode",
        options=[
            "🟢 Offline Local Mode (No API Required)",
            "☁️ Google Gemini API",
            "🤖 OpenAI API",
            "💻 Local Ollama (Self-Hosted)"
        ],
        index=0
    )

    if "Offline" in mode:
        st.success("🔒 **100% Offline Mode Active**\n\nRuns completely on your local device. No internet calls, no API keys, zero cost.")
        st.session_state.rag_engine.update_llm_config(provider="offline")

    elif "Gemini" in mode:
        api_key = st.text_input(
            "Gemini API Key",
            value=st.session_state.gemini_key,
            type="password",
            help="Get your key at https://aistudio.google.com"
        )
        model_choice = st.selectbox(
            "Gemini Model",
            options=["gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash"],
            index=0
        )
        st.session_state.gemini_key = api_key
        st.session_state.rag_engine.update_llm_config(
            provider="gemini",
            gemini_api_key=api_key,
            model_name=model_choice
        )

    elif "OpenAI" in mode:
        api_key = st.text_input(
            "OpenAI API Key",
            value=st.session_state.openai_key,
            type="password"
        )
        model_choice = st.selectbox(
            "OpenAI Model",
            options=["gpt-4o-mini", "gpt-4o"],
            index=0
        )
        st.session_state.openai_key = api_key
        st.session_state.rag_engine.update_llm_config(
            provider="openai",
            openai_api_key=api_key,
            model_name=model_choice
        )
    else:
        ollama_model = st.text_input("Ollama Model Name", value="llama3.2")
        st.session_state.rag_engine.update_llm_config(
            provider="ollama",
            model_name=ollama_model
        )

    st.markdown("---")
    st.subheader("📁 Document Ingestion")
    
    uploaded_files = st.file_uploader(
        "Upload Documents or Diagrams",
        type=["pdf", "docx", "txt", "md", "csv", "xlsx", "png", "jpg", "jpeg"],
        accept_multiple_files=True
    )

    # Retrieval tuning
    with st.expander("🛠️ Advanced RAG Parameters"):
        chunk_size = st.slider("Chunk Size (characters)", 300, 1500, DEFAULT_CHUNK_SIZE, 50)
        chunk_overlap = st.slider("Chunk Overlap", 50, 400, DEFAULT_CHUNK_OVERLAP, 25)
        top_k = st.slider("Top-K Retrieved Chunks", 1, 8, DEFAULT_TOP_K)
        use_hybrid = st.checkbox("Hybrid Search (Dense + BM25)", value=True)
        extract_visuals = st.checkbox("Extract & Analyze Diagrams/Figures", value=True)

    if st.button("🚀 Process & Index Documents", use_container_width=True, type="primary"):
        if not uploaded_files:
            st.warning("Please upload at least one document first.")
        else:
            total_docs = len(uploaded_files)
            progress_bar = st.progress(0)
            status_text = st.empty()

            for idx, uploaded_file in enumerate(uploaded_files):
                status_text.text(f"Processing ({idx+1}/{total_docs}): {uploaded_file.name}...")
                
                # Save temp file
                suffix = Path(uploaded_file.name).suffix
                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(uploaded_file.getbuffer())
                    tmp_path = Path(tmp.name)

                try:
                    res = st.session_state.rag_engine.ingest_file(
                        file_path=tmp_path,
                        original_filename=uploaded_file.name,
                        chunk_size=chunk_size,
                        chunk_overlap=chunk_overlap,
                        extract_visuals=extract_visuals
                    )
                finally:
                    if tmp_path.exists():
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass

                progress_bar.progress((idx + 1) / total_docs)

            status_text.success("All documents indexed successfully!")
            st.rerun()

    # Knowledge Base Overview Stats
    stats = st.session_state.rag_engine.get_stats()
    st.markdown("---")
    st.markdown("### 📊 Knowledge Base Stats")
    col1, col2 = st.columns(2)
    col1.metric("Total Chunks", stats["total_chunks"])
    col2.metric("Diagrams", stats["visual_count"])

    if stats["sources"]:
        st.caption("Active Documents:")
        for src in stats["sources"]:
            st.markdown(f"- 📄 `{src}`")

    if st.button("🗑️ Clear Knowledge Base", use_container_width=True):
        st.session_state.rag_engine.clear()
        st.session_state.messages = []
        st.success("Knowledge base cleared.")
        st.rerun()

# ----------------- MAIN INTERFACE -----------------
st.markdown('<div class="main-title">🧠 SmartRAG: Intelligent Document Q&A</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="sub-title">'
    '<span class="badge">🟢 100% Offline (No API Needed)</span>'
    '<span class="badge">Hybrid Search (Dense + BM25)</span>'
    '<span class="badge">Visual Diagram & OCR Aware</span>'
    '<span class="badge">Traceable Citations</span>'
    '</div>',
    unsafe_allow_html=True
)

tab_chat, tab_gallery, tab_inspector = st.tabs(["💬 Chat & Q&A", "🖼️ Extracted Visuals Gallery", "🔍 Chunk Inspector"])

# ----------------- TAB 1: CHAT -----------------
with tab_chat:
    # Display quick prompt suggestions if no messages
    if not st.session_state.messages:
        st.info("💡 **Welcome to SmartRAG!** Upload documents in the sidebar, or ask a question once indexed.")
        col_s1, col_s2, col_s3 = st.columns(3)
        if col_s1.button("📋 Summarize uploaded documents", use_container_width=True):
            st.session_state.pending_query = "Summarize the key topics and conclusions of the uploaded documents."
            st.rerun()
        if col_s2.button("🖼️ Explain diagrams & charts", use_container_width=True):
            st.session_state.pending_query = "What diagrams, architectures, or charts are present, and what do they show?"
            st.rerun()
        if col_s3.button("🔍 What are the key findings?", use_container_width=True):
            st.session_state.pending_query = "List the key findings, data points, or recommendations from the documents."
            st.rerun()

    # Render Chat History
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            
            # Display inline visual citations if any
            visuals = msg.get("visual_citations", [])
            if visuals:
                st.markdown("**🖼️ Referenced Figures & Diagrams:**")
                cols = st.columns(min(len(visuals), 3))
                for v_idx, v_path in enumerate(visuals):
                    if os.path.exists(v_path):
                        with cols[v_idx % 3]:
                            st.image(v_path, caption=f"Figure {v_idx+1}", use_container_width=True)

            # Display textual citations in expander
            citations = msg.get("citations", [])
            if citations:
                with st.expander(f"📑 Sources & Citations ({len(citations)} references)"):
                    for c in citations:
                        badge_color = "🏷️ Visual Figure" if c["type"] == "visual" else "📄 Text Chunk"
                        st.markdown(
                            f"**Source {c['index']}:** `{c['source']}` — Page {c['page']} ({badge_color})  \n"
                            f"*Match Score:* `{c['score']}`  \n"
                            f"_{c['preview']}_"
                        )
                        st.markdown("---")

    # Chat input or pending query
    user_query = st.chat_input("Ask any question about your documents, charts, or diagrams...")
    
    if "pending_query" in st.session_state and st.session_state.pending_query:
        user_query = st.session_state.pending_query
        del st.session_state.pending_query

    if user_query:
        # Check if knowledge base is empty
        current_stats = st.session_state.rag_engine.get_stats()
        if current_stats["total_chunks"] == 0:
            st.warning("⚠️ No documents have been indexed yet. Please upload files in the sidebar and click 'Process & Index Documents'.")
        else:
            # Append user message
            st.session_state.messages.append({"role": "user", "content": user_query})
            with st.chat_message("user"):
                st.markdown(user_query)

            # Generate Assistant Answer
            with st.chat_message("assistant"):
                with st.spinner("Retrieving hybrid context & analyzing diagrams..."):
                    response = st.session_state.rag_engine.ask(
                        query=user_query,
                        conversation_history=st.session_state.messages[:-1],
                        top_k=top_k,
                        use_hybrid=use_hybrid
                    )

                st.markdown(response["answer"])

                # Render Visual Citations
                visuals = response.get("visual_citations", [])
                if visuals:
                    st.markdown("**🖼️ Referenced Figures & Diagrams:**")
                    cols = st.columns(min(len(visuals), 3))
                    for v_idx, v_path in enumerate(visuals):
                        if os.path.exists(v_path):
                            with cols[v_idx % 3]:
                                st.image(v_path, caption=f"Referenced Figure {v_idx+1}", use_container_width=True)

                # Render Citations
                citations = response.get("citations", [])
                if citations:
                    with st.expander(f"📑 Sources & Citations ({len(citations)} references)"):
                        for c in citations:
                            badge_color = "🏷️ Visual Figure" if c["type"] == "visual" else "📄 Text Chunk"
                            st.markdown(
                                f"**Source {c['index']}:** `{c['source']}` — Page {c['page']} ({badge_color})  \n"
                                f"*Match Score:* `{c['score']}`  \n"
                                f"_{c['preview']}_"
                            )
                            st.markdown("---")

                # Store assistant response in history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response["answer"],
                    "citations": citations,
                    "visual_citations": visuals
                })

# ----------------- TAB 2: VISUAL GALLERY -----------------
with tab_gallery:
    st.subheader("🖼️ Extracted Visual Figures & Diagrams")
    st.markdown("All diagrams, architecture charts, plots, and tables parsed from your documents:")

    all_visuals = st.session_state.rag_engine.get_all_visuals()
    if not all_visuals:
        st.info("No diagrams or figures have been extracted yet. Upload a PDF or DOCX containing images/charts and index it.")
    else:
        gallery_cols = st.columns(2)
        for idx, item in enumerate(all_visuals):
            with gallery_cols[idx % 2]:
                st.markdown('<div class="visual-card">', unsafe_allow_html=True)
                if os.path.exists(item["image_path"]):
                    st.image(item["image_path"], use_container_width=True)
                st.markdown(f"**Document:** `{item['source']}` (Page {item['page']})")
                st.caption(item["caption"])
                st.markdown('</div>', unsafe_allow_html=True)

# ----------------- TAB 3: CHUNK INSPECTOR -----------------
with tab_inspector:
    st.subheader("🔍 Knowledge Base Inspection")
    all_chunks = st.session_state.rag_engine.vector_store.get_all_chunks()
    
    if not all_chunks:
        st.info("Knowledge base is currently empty.")
    else:
        st.write(f"Total Chunks in Storage: **{len(all_chunks)}**")
        for idx, chunk in enumerate(all_chunks[:50]):  # Show up to first 50
            meta = chunk.get("metadata", {})
            chunk_type = meta.get("type", "text")
            with st.expander(f"Chunk #{idx+1} — {meta.get('source', 'Unknown')} (Page {meta.get('page', 1)}) [{chunk_type}]"):
                st.json(meta)
                st.text_area("Content", value=chunk["content"], height=100, key=f"inspect_{chunk['id']}")

