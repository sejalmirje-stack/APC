@echo off
title SmartRAG - Multimodal Intelligent Document QA
cls
echo ================================================================
echo           SmartRAG: Intelligent Document Q&A System
echo             (100%% Offline Local & Multimodal Capable)
echo ================================================================
echo.

:: Set UTF-8 encoding environment for Python on Windows
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python was not found in your system PATH!
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b 1
)

echo [INFO] Python environment verified.
echo [INFO] Starting SmartRAG Web Dashboard on http://localhost:8501 ...
echo [INFO] Close this window when you want to stop the server.
echo.

:: Launch Streamlit app
python -m streamlit run app.py

pause
